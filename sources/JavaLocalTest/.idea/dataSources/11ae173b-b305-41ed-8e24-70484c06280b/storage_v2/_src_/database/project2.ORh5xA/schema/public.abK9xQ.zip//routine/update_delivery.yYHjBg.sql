create function update_delivery() returns trigger
    language plpgsql
as
$$
DECLARE
    container_using bool;
BEGIN
    case NEW.state
        when 'Picking-up'
            then RAISE EXCEPTION 'failed';
        when 'To-Export Transporting'
            then if OLD.state like 'Picking-up' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Export Checking'
            then if OLD.state like 'To-Export Transporting' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Export Check Fail'
            then if OLD.state like 'Export Checking' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Packing to Container'
            then if OLD.state like 'Export Checking' then
                return new;
                 elseif OLD.state like 'Packing to Container' then
                     select "using"
                     from container
                     where code like NEW.container_code
                     into container_using;
                     if container_using is false then
                         delete
                         from sea_transportation
                         where item_name like old.item_name;
                         update container
                         set "using" = true
                         where code like NEW.container_code;
                         insert into sea_transportation
                         values (new.item_name, new.container_code, null, new.company);
                         return new;
                     end if;
                 end if;
                 raise exception 'failed';
        when 'Waiting for Shipping'
            then if OLD.state like 'Packing to Container' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Shipping'
            then if OLD.state like 'Waiting for Shipping' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Unpacking from Container'
            then if OLD.state like 'Shipping' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Import Checking'
            then if OLD.state like 'Unpacking from Container' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Import Check Fail'
            then if OLD.state like 'Import Checking' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'From-Import Transporting'
            then if OLD.state like ('Import Checking' or 'From-Import Transporting') and
                    OLD.delivery_courier_id is null then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Delivering'
            then if OLD.state like 'From-Import Transporting' then
                return new;
            else
                raise exception 'failed';
            end if;
        when 'Finish'
            then if OLD.state like 'Delivering' then
                return new;
            else
                raise exception 'failed';
            end if;
        end case;
    return null;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION '(%)', SQLERRM;
END ;
$$;

alter function update_delivery() owner to postgres;

