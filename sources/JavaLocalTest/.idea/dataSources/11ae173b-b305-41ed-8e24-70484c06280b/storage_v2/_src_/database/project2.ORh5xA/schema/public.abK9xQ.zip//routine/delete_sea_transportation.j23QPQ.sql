create function delete_sea_transportation() returns trigger
    language plpgsql
as
$$
DECLARE
    count integer;
BEGIN
    if old.ship_name is not null then
        update delivery
        set state = 'Unpacking from Container'
        where item_name like old.item_name;
        select count(*) from sea_transportation where ship_name like old.ship_name into count;
        if (count = 1) then
            update ship set sailing = false where name like old.ship_name;
        end if;
    end if;
    update container
    set "using" = false
    where code like old.container_code;
    return old;
END;
$$;

alter function delete_sea_transportation() owner to postgres;

