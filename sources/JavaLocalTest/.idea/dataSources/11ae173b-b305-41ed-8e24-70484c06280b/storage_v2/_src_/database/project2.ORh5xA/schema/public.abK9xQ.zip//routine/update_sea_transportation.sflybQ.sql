create function update_sea_transportation() returns trigger
    language plpgsql
as
$$
BEGIN
    if (old.ship_name is null and new.ship_name is not null) then
        update delivery
        set (state, ship_name) = ('Waiting for Shipping', new.ship_name)
        where item_name like new.item_name;
        return new;
    end if;
    return null;
END;
$$;

alter function update_sea_transportation() owner to postgres;

