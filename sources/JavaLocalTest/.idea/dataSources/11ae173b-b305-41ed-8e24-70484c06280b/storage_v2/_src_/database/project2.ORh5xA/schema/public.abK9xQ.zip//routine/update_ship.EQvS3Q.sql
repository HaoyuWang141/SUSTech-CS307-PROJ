create function update_ship() returns trigger
    language plpgsql
as
$$
BEGIN
    if old.sailing is false and new.sailing is true
    then
        update delivery
        set state = 'Shipping'
        where ship_name like old.name
          and state like 'Waiting for Shipping';
        return new;
    end if;
    if old.sailing is true and new.sailing is false
    then
        return new;
    end if;
    RAISE EXCEPTION 'something wrong';
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION '(%)', SQLERRM;
END;
$$;

alter function update_ship() owner to postgres;

