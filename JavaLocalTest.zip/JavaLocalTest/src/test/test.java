package test;

import main.DBManipulation;
import main.interfaces.LogInfo;
import test.answers.CompanyManagerUserTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static test.LocalJudge.*;

public class test {
    public static void main(String[] args) throws IOException {
        DBManipulation d = new DBManipulation(database, root, pass);
        recordsCSV = "./data/test_records.csv";
        staffsCSV = "./data/test_staffs.csv";
        d.$import(readFile(recordsCSV), readFile(staffsCSV));
        d.unloadItem(new LogInfo("e", LogInfo.StaffType.CompanyManager,"111111"), "test1");
        d.unloadItem(new LogInfo("e", LogInfo.StaffType.CompanyManager,"111111"), "test2");
    }
}
