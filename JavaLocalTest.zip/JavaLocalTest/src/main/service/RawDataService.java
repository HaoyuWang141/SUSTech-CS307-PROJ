package main.service;

import main.enumcase.INSERT_TYPE;
import main.enumcase.SOURCE;

public interface RawDataService extends Service{
    void importData(boolean verbose, SOURCE source, INSERT_TYPE type);

    void importData2(String recordsCSV, String staffsCSV);
}
