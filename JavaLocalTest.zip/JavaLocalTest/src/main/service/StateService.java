package main.service;

public interface StateService extends Service {
    void importData();
}
