package main.service;

public interface StaffTypeService extends Service{
    void importData();
}
