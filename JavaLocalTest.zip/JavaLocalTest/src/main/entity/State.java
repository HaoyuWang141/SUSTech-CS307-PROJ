package main.entity;

public class State extends Entity{
    private String state;

    public State(String state) {
        this.state = state;
    }
}
