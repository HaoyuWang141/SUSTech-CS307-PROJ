package main.entity;

public abstract class Entity {
}
