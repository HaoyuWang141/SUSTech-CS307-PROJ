package main.entity;

public class StaffType extends Entity{
    private String type;

    public StaffType(String type) {
        this.type = type;
    }
}
