package main;

import main.enumcase.SOURCE;
import main.interfaces.*;
import main.entity.*;
import main.service.*;
import main.service.impl.*;
import main.util.PostgresqlUtil;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.Calendar;

import static main.interfaces.ItemState.*;
import static main.util.PostgresqlUtil.*;

public class DBManipulation implements IDatabaseManipulation {

    CityService cityService = new CityServiceImpl();
    CityTaxService cityTaxService = new CityTaxServiceImpl();
    CompanyService companyService = new CompanyServiceImpl();
    ContainerService containerService = new ContainerServiceImpl();
    DeliveryService deliveryService = new DeliveryServiceImpl();
    LogService logService = new LogServiceImpl();
    RawDataService rawDataService = new RawDataServiceImpl();
    SeaTransportationService seaTransportationService = new SeaTransportationServiceImpl();
    ShipService shipService = new ShipServiceImpl();
    StaffService staffService = new StaffServiceImpl();
    StaffTypeService staffTypeService = new StaffTypeServiceImpl();
    StateService stateService = new StateServiceImpl();

    public DBManipulation(String database, String root, String pass) {
        PostgresqlUtil.database = database;
        PostgresqlUtil.root = root;
        PostgresqlUtil.pass = pass;

        Statement stmt = null;
        Connection connection = null;
        try {
            // connection
            connection = PostgresqlUtil.getConnection(database, root, pass);
            System.out.println("project_interface constructor start");
            String sql_DDL = readFile("sql/1_DDL.sql");
            String sql_trigger = readFile("sql/2_trigger.sql");
            String sql_authority = readFile("sql/3_authority.sql");
            stmt = connection.createStatement();
            stmt.execute(sql_DDL);
            if (verbose)
                System.out.println("create tables successfully");
            stmt.execute(sql_trigger);
            if (verbose)
                System.out.println("create triggers successfully");
            stmt.execute(sql_authority);
            if (verbose)
                System.out.println("create roles successfully");
            connection.commit();
        } catch (Exception e) {
            System.out.println(e.getMessage());
//            e.printStackTrace();
        } finally {
            PostgresqlUtil.closeResource(connection, stmt);
        }
    }

    @Override
    public void $import(String recordsCSV, String staffsCSV) {
        rawDataService.importData2(recordsCSV, staffsCSV);
        cityService.importData(verbose, SOURCE.database);
        cityTaxService.importData(verbose, SOURCE.database);
        companyService.importData(verbose, SOURCE.database);
        containerService.importData(verbose, SOURCE.database);
        staffTypeService.importData();
        staffService.importData(verbose, SOURCE.database);
        logService.importData();
        shipService.importData(verbose, SOURCE.database);
        stateService.importData();
        deliveryService.importData(verbose, SOURCE.database);
        seaTransportationService.importData();
    }

    /**
     * Company Manager
     */
    @Override
    public double getImportTaxRate(LogInfo logInfo, String city, String itemClass) {
        double result = -1.;
        if (logInfo.type() == LogInfo.StaffType.CompanyManager && logService.check_logInfo(logInfo)) {
            CON = getConnection("loader_CompanyManager.cnf");
            result = cityTaxService.getImportTaxRate("loader_CompanyManager.cnf", city, itemClass);
        }
        closeResource(CON);
        return result;
    }

    @Override
    public double getExportTaxRate(LogInfo logInfo, String city, String itemClass) {
        double result = -1.;
        if (logInfo.type() == LogInfo.StaffType.CompanyManager && logService.check_logInfo(logInfo)) {
            CON = getConnection("loader_CompanyManager.cnf");
            result = cityTaxService.getExportTaxRate("loader_CompanyManager.cnf", city, itemClass);
        }
        closeResource(CON);
        return result;
    }

    @Override
    public boolean loadItemToContainer(LogInfo logInfo, String itemName, String containerCode) {
        if (logInfo.type() == LogInfo.StaffType.CompanyManager && logService.check_logInfo(logInfo)) {
            if (!containerService.getUsing("loader_CompanyManager.cnf", containerCode))
                return deliveryService.updateContainer_atState_PackingToContainer("loader_CompanyManager.cnf", itemName, containerCode);
        }
        return false;
    }

    @Override
    public boolean loadContainerToShip(LogInfo logInfo, String shipName, String containerCode) {
        if (logInfo.type() == LogInfo.StaffType.CompanyManager && logService.check_logInfo(logInfo)) {
            if (!shipService.getSailing("loader_CompanyManager.cnf", shipName)
                && containerService.getUsing("loader_CompanyManager.cnf", containerCode)
                && seaTransportationService.getShipName_by_containerCode("loader_CompanyManager.cnf", containerCode) == null) {
                return seaTransportationService.updateShip_by_containerCode("loader_CompanyManager.cnf", containerCode, shipName);
            }
        }
        return false;
    }

    @Override
    public boolean shipStartSailing(LogInfo logInfo, String shipName) {
        if (logInfo.type() == LogInfo.StaffType.CompanyManager && logService.check_logInfo(logInfo))
            if (!shipService.getSailing("loader_CompanyManager.cnf", shipName) && seaTransportationService.getItemCount_by_Ship("loader_CompanyManager.cnf", shipName) > 0)
                return shipService.shipStartSailing("loader_CompanyManager.cnf", shipName);
        return false;
    }

    @Override
    public boolean unloadItem(LogInfo logInfo, String itemName) {
        if (logInfo.type() == LogInfo.StaffType.CompanyManager && logService.check_logInfo(logInfo)) {
            String ship = seaTransportationService.getShipName_by_itemName("loader_CompanyManager.cnf", itemName);
            if (ship != null)
                return seaTransportationService.delete_by_Item("loader_CompanyManager.cnf", itemName);
        }
        return false;
    }

    @Override
    public boolean itemWaitForChecking(LogInfo logInfo, String itemName) {
        if (logInfo.type() == LogInfo.StaffType.CompanyManager && logService.check_logInfo(logInfo))
            return deliveryService.setItemState_ImportChecking("loader_CompanyManager.cnf", itemName);
        else return false;
    }

    /**
     * Courier
     */
    @Override
    public boolean newItem(LogInfo logInfo, ItemInfo itemInfo) {
        if (logInfo.type() == LogInfo.StaffType.Courier && logService.check_logInfo(logInfo)) {
            CON = getConnection("loader_Courier.cnf");
            if (itemInfo.export().officer() == null
                && itemInfo.$import().officer() == null
                && itemInfo.delivery().courier() == null
                && itemInfo.state() == null
                && itemInfo.price() > 0
                && Math.abs((cityTaxService.getExportTaxRate("loader_Courier.cnf", itemInfo.export().city(), itemInfo.$class()) * itemInfo.price() - itemInfo.export().tax())) / itemInfo.export().tax() < ERROR
                && Math.abs((cityTaxService.getImportTaxRate("loader_Courier.cnf", itemInfo.$import().city(), itemInfo.$class()) * itemInfo.price() - itemInfo.$import().tax())) / itemInfo.$import().tax() < ERROR
                && itemInfo.retrieval().city().equals(staffService.getStaffCity("loader_Courier.cnf", logInfo.name()))
                && !itemInfo.retrieval().city().equals(itemInfo.$import().city())
                && !itemInfo.retrieval().city().equals(itemInfo.delivery().city())
                && !itemInfo.export().city().equals(itemInfo.$import().city())
                && !itemInfo.export().city().equals(itemInfo.delivery().city())
            ) // 部分信息要求是null
            {
                Delivery delivery = new Delivery(
                        itemInfo.name(),
                        itemInfo.$class(),
                        itemInfo.price(),
                        itemInfo.retrieval().city(),
                        staffService.getStaffId("loader_Courier.cnf", logInfo.name()),
                        itemInfo.export().city(),
                        null,
                        itemInfo.$import().city(),
                        null,
                        itemInfo.delivery().city(),
                        null,
                        null,
                        null,
                        staffService.getStaffCompany("loader_Courier.cnf", logInfo.name()),
                        "Picking-up"
                );
                return deliveryService.insertDelivery("loader_Courier.cnf", delivery);
            }
        }
        closeResource(CON);
        return false;
    }

    @Override
    public boolean setItemState(LogInfo logInfo, String itemName, ItemState itemState) {
        boolean flag  = false;
        if (logInfo.type() == LogInfo.StaffType.Courier && logService.check_logInfo(logInfo)) {
            CON = getConnection("loader_Courier.cnf");
            int staffId = staffService.getStaffId("loader_Courier.cnf", logInfo.name());
            if (itemState.equals(ToExportTransporting)) {
                flag = deliveryService.setItemState_ToExportTransporting("loader_Courier.cnf", itemName, staffId);
            } else if (itemState.equals(ExportChecking)) {
                flag = deliveryService.setItemState_ExportChecking("loader_Courier.cnf", itemName, staffId);
            } else if (itemState.equals(FromImportTransporting)) {
                flag = deliveryService.update_DeliveryCourierStaffId_atState_FromImportTransporting("loader_Courier.cnf", itemName, staffId);
            } else if (itemState.equals(Delivering)) {
                flag = deliveryService.setItemState_Delivering("loader_Courier.cnf", itemName, staffId);
            } else if (itemState.equals(Finish)) {
                flag = deliveryService.setItemState_Finish("loader_Courier.cnf", itemName, staffId);
            }
        }
        closeResource(CON);
        return flag;
    }

    /**
     * Seaport Officer
     */
    @Override
    public String[] getAllItemsAtPort(LogInfo logInfo) {
        String[] result = null;
        if (logInfo.type() == LogInfo.StaffType.SeaportOfficer && logService.check_logInfo(logInfo)) {
            CON = getConnection("loader_SeaportOfficer.cnf");
            String city = staffService.getStaffCity("loader_SeaportOfficer.cnf", logInfo.name());
            result = deliveryService.getAllItemNameAtPort("loader_SeaportOfficer.cnf", city);
        }
        closeResource(CON);
        return result;
    }

    @Override
    public boolean setItemCheckState(LogInfo logInfo, String itemName, boolean success) {
        boolean result = false;
        if (logInfo.type() == LogInfo.StaffType.SeaportOfficer && logService.check_logInfo(logInfo)) {
            CON = getConnection("loader_SeaportOfficer.cnf");
            ItemState itemState = getItemState_from_String(deliveryService.getState("loader_SeaportOfficer.cnf", itemName));
            int staffId = staffService.getStaffId("loader_SeaportOfficer.cnf", logInfo.name());
            String staffCity = staffService.getStaffCity("loader_SeaportOfficer.cnf", logInfo.name());
            if (itemState.equals(ExportChecking)) {
                if (success)
                    result = deliveryService.setItemState_PackingToContainer("loader_SeaportOfficer.cnf", itemName, staffId, staffCity);
                else
                    result = deliveryService.setItemState_ExportCheckFail("loader_SeaportOfficer.cnf", itemName, staffId, staffCity);
            } else if (itemState.equals(ImportChecking)) {
                if (success)
                    result = deliveryService.setItemState_FromImportTransporting("loader_SeaportOfficer.cnf", itemName, staffId, staffCity);
                else
                    result = deliveryService.setItemState_ImportCheckFail("loader_SeaportOfficer.cnf", itemName, staffId, staffCity);
            }
        }
        closeResource(CON);
        return result;
    }


    /**
     * Sustc Manager
     */
    @Override
    public int getCompanyCount(LogInfo logInfo) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo))
            return companyService.getCompanyCount("loader_SUSTCDepartmentManager.cnf");
        else return -1;
    }

    @Override
    public int getCityCount(LogInfo logInfo) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo))
            return cityService.getCityCount("loader_SUSTCDepartmentManager.cnf");
        else return -1;
    }

    @Override
    public int getCourierCount(LogInfo logInfo) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo))
            return staffService.getCourierCount("loader_SUSTCDepartmentManager.cnf");
        else return -1;
    }

    @Override
    public int getShipCount(LogInfo logInfo) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo))
            return shipService.getShipCount("loader_SUSTCDepartmentManager.cnf");
        else return -1;
    }

    @Override
    public ItemInfo getItemInfo(LogInfo logInfo, String item_name) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo)) {

            CON = getConnection("loader_SUSTCDepartmentManager.cnf");

            Delivery deliveryRecord = deliveryService.getDelivery("loader_SUSTCDepartmentManager.cnf", item_name);
            if (deliveryRecord != null) {

                ItemInfo.RetrievalDeliveryInfo retrieval = new ItemInfo.RetrievalDeliveryInfo(deliveryRecord.getRetrieval_city(),
                        staffService.getStaffName("loader_SUSTCDepartmentManager.cnf", deliveryRecord.getRetrieval_courier_id()));

                ItemInfo.RetrievalDeliveryInfo delivery = new ItemInfo.RetrievalDeliveryInfo(deliveryRecord.getDelivery_city(),
                        staffService.getStaffName("loader_SUSTCDepartmentManager.cnf", deliveryRecord.getDelivery_courier_id()));

                ItemInfo.ImportExportInfo export = new ItemInfo.ImportExportInfo(deliveryRecord.getExport_city(),
                        staffService.getStaffName("loader_SUSTCDepartmentManager.cnf", deliveryRecord.getExport_officer_id()),
                        cityTaxService.getExportTaxRate("loader_SUSTCDepartmentManager.cnf",
                                deliveryRecord.getExport_city(), deliveryRecord.getItem_type()) * deliveryRecord.getItem_price());

                ItemInfo.ImportExportInfo $import = new ItemInfo.ImportExportInfo(deliveryRecord.getImport_city(),
                        staffService.getStaffName("loader_SUSTCDepartmentManager.cnf", deliveryRecord.getImport_officer_id()),
                        cityTaxService.getImportTaxRate("loader_SUSTCDepartmentManager.cnf",
                                deliveryRecord.getImport_city(), deliveryRecord.getItem_type()) * deliveryRecord.getItem_price());

                return new ItemInfo(
                        deliveryRecord.getItem_name(),
                        deliveryRecord.getItem_type(),
                        deliveryRecord.getItem_price(),
                        getItemState_from_String(deliveryRecord.getState()),
                        retrieval,
                        delivery,
                        $import,
                        export
                );
            }

            closeResource(CON);
        }
        return null;
    }

    @Override
    public ShipInfo getShipInfo(LogInfo logInfo, String ship_name) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo)) {
            Ship ship = shipService.getShip("loader_SUSTCDepartmentManager.cnf", ship_name);
            if (ship != null)
                return new ShipInfo(ship.getName(), ship.getCompany(), ship.getSailing());
        }
        return null;
    }

    @Override
    public ContainerInfo getContainerInfo(LogInfo logInfo, String container_code) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo)) {
            Container container = containerService.getContainer("loader_SUSTCDepartmentManager.cnf", container_code);
            if (container != null)
                return new ContainerInfo(getContinerTypeFromString(container.getType()), container.getCode(), container.getUsing());
        }
        return null;
    }

    @Override
    public StaffInfo getStaffInfo(LogInfo logInfo, String staff_name) {
        if (logInfo.type() == LogInfo.StaffType.SustcManager && logService.check_logInfo(logInfo)) {
            CON = getConnection("loader_SUSTCDepartmentManager.cnf");
            Staff staff = staffService.getStaff("loader_SUSTCDepartmentManager.cnf", staff_name);
            Calendar ca = Calendar.getInstance();
            ca.setTime(staff.getBirth_year());
            int year = ca.get(Calendar.YEAR);
            String password = logService.getPassword("loader_SUSTCDepartmentManager.cnf", staff.getId());
            LogInfo l = new LogInfo(staff.getName(), LogInfo.StaffType.valueOf(staff.getType().replaceAll(" ", "").equals("SUSTCDepartmentManager") ? "SustcManager" : staff.getType().replaceAll(" ", "")), password);
            closeResource(CON);
            return new StaffInfo(l, staff.getCompany(), staff.getCity(), staff.getGender().equals("female"), 2022 - year, staff.getPhone_number());
        }
        return null;
    }

    private String readFile(String path) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(path));
        StringBuilder sb = new StringBuilder();
        reader.lines().forEach(l -> {
            sb.append(l);
            sb.append("\n");
        });
        return sb.toString();
    }

    private ContainerInfo.Type getContinerTypeFromString(String type) {
        String[] tmp = type.split(" ");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i <= tmp.length - 2; i++)
            result.append(tmp[i]);
        return ContainerInfo.Type.valueOf(result.toString());
    }

    private static ItemState getItemState_from_String(String state) {
        switch (state) {
            case "Import Checking":
                return ImportChecking;
            case "Import Check Fail":
                return ImportCheckFailed;
            case "Export Checking":
                return ExportChecking;
            case "Export Check Fail":
                return ExportCheckFailed;
            case "Unpacking from Container":
                return UnpackingFromContainer;
            case "Delivering":
                return Delivering;
            case "To-Export Transporting":
                return ToExportTransporting;
            case "Finish":
                return Finish;
            case "Shipping":
                return Shipping;
            case "From-Import Transporting":
                return FromImportTransporting;
            case "Waiting for Shipping":
                return WaitingForShipping;
            case "Packing to Container":
                return PackingToContainer;
            case "Picking-up":
                return PickingUp;
        }
        return null;
    }
}
