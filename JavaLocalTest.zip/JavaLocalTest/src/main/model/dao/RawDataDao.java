package main.model.dao;

import main.entity.Entity;

public interface RawDataDao extends Dao {

    void insert_A(boolean verbose, Entity[] entities);
    void insert_B(boolean verbose, Entity[] entities);

    void loadAndImport_from_csv(String recordsCSV,String staffsCSV);
}