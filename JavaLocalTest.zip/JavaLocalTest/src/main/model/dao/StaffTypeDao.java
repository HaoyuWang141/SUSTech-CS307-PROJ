package main.model.dao;

public interface StaffTypeDao extends Dao{
}
