package main.model.dao;

public interface CityDao extends Dao {
    int getCityCount(String loader_cnf);
}
