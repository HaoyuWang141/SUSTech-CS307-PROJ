package main.model.dao;

public interface StateDao extends Dao {
}
