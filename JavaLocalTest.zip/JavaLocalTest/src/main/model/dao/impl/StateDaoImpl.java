package main.model.dao.impl;

import main.entity.Entity;
import main.enumcase.ExitStatus;
import main.model.dao.StateDao;
import main.util.PostgresqlUtil;

import java.sql.Connection;
import java.sql.Statement;

public class StateDaoImpl implements StateDao {
    Connection connection = null;

    @Override
    public Entity[] loadData(boolean verbose) {
        return new Entity[0];
    }

    @Override
    public void importData(boolean verbose) {
        Statement stmt = null;
        try {
            // connection
            connection = PostgresqlUtil.getConnectionRoot();
            System.out.println("StateDaoImpl importData() start");

            // Drop table
            stmt = connection.createStatement();
            stmt.execute("truncate table state cascade;");

            // import from raw_data
            String sql = """
                    insert into state(name)
                    select distinct "Item State" from raw_data_records;
                    """;
            stmt.execute(sql);
            connection.commit();

            System.out.println("Load Data into table state SUCCESSFULLY.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.SQLException.getCode());
        } finally {
            PostgresqlUtil.closeResource(connection, stmt);
            System.out.println();
        }
    }

    @Override
    public void insert(boolean verbose, Entity[] entities) {

    }

    @Override
    public void dropAll(boolean verbose) {

    }
}
