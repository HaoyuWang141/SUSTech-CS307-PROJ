package main.model.dao.impl;

import main.entity.Entity;
import main.entity.RawData;
import main.enumcase.ExitStatus;
import main.model.dao.RawDataDao;
import main.util.PostgresqlUtil;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;

import static main.util.PostgresqlUtil.*;

public class RawDataDaoImpl implements RawDataDao {
    private static final int OUTPUT_COUNT = 50000;
    private Connection connection = null;

    @Override
    public Entity[] loadData(boolean verbose) {
        ArrayList<RawData> rawData_list = new ArrayList<>();
        long start_time;
        long end_time;
        try {
            connection = PostgresqlUtil.getConnection(verbose);
            if (verbose)
                System.out.println("RawDataDaoImpl loadData() start");
            start_time = System.currentTimeMillis();
            String sql = "select * from raw_data";
            ResultSet resultSet = execute_query(connection, sql, null);
            end_time = System.currentTimeMillis();
            System.out.println("Load Data into java from table raw_data successfully in " + (end_time - start_time) / 1000f + " s");
            while (resultSet.next()) {
                RawData rawData = new RawData();
                System.err.println("lksajdflksadfjlkasdjfal");
                rawData_list.add(rawData);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.SQLException.getCode());
        } finally {
            PostgresqlUtil.closeResource(connection);
            System.out.println();
        }
        return rawData_list.toArray(new RawData[0]);
    }

    @Override
    public void insert(boolean verbose, Entity[] entities) {
        insert_A(verbose, entities);
    }

    @Override
    public void insert_A(boolean verbose, Entity[] entities) {
        RawData[] rawData_list = null;
        try {
            rawData_list = (RawData[]) entities;
        } catch (ClassCastException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.ParameterException.getCode());
        }
        long start_time;
        long end_time;
        long tmp_time;
        int cnt = 0;
        start_time = System.currentTimeMillis();
        PreparedStatement prestmt = null;
        try {
            connection = PostgresqlUtil.getConnection(verbose);
            if (verbose)
                System.out.println("RawDataDaoImpl insert_A() start");
            prestmt = connection.prepareStatement("insert into raw_data"
                    + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            tmp_time = System.currentTimeMillis();
            for (RawData rawData : rawData_list) {
                Serializable[] fields = rawData.getAllFields();
                for (int i = 0; i < fields.length; i++) {
                    PostgresqlUtil.replace_placeholder(prestmt, i + 1, fields[i]);
                }
                prestmt.addBatch();
                cnt++;
                if (cnt % BATCH_SIZE == 0) {
                    prestmt.executeBatch();
                    prestmt.clearBatch();

                }
                if (verbose && cnt % OUTPUT_COUNT == 0) {
                    long t = System.currentTimeMillis();
                    System.out.printf("Have Loaded 50000 data in %.3f s!\n", (t - tmp_time) / 1000f);
                    tmp_time = t;
                }
            }
            if (cnt % BATCH_SIZE != 0) {
                prestmt.executeBatch();
            }
            connection.commit();
            if (verbose)
                System.out.println("Commit!");
            end_time = System.currentTimeMillis();
            if (verbose) {
                System.out.println("Insert RawData Objects into table raw_data from data.csv successfully. " + cnt + " records are loaded");
                System.out.println("Loading Time : " + (end_time - start_time) / 1000f + " s");
                System.out.println("Loading speed : " + (cnt * 1000L) / (end_time - start_time) + " records/s");
            } else {
                System.out.println("RawDataDaoImpl insert_A() : " + " Batch Size = " + BATCH_SIZE + ", Time : " + (end_time - start_time) / 1000f + " s");
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
            try {
                connection.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            System.exit(3);
        } finally {
            PostgresqlUtil.closeResource(connection, prestmt);
            System.out.println();
        }
    }

    @Override
    public void insert_B(boolean verbose, Entity[] entities) {
        RawData[] rawData_list = null;
        try {
            rawData_list = (RawData[]) entities;
        } catch (ClassCastException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.ParameterException.getCode());
        }
        long start_time;
        long end_time;
        long tmp_time;
        int cnt = 0;
        start_time = System.currentTimeMillis();
        PreparedStatement prestmt = null;
        try {
            connection = PostgresqlUtil.getConnection(verbose);
            if (verbose)
                System.out.println("RawDataDaoImpl insert_B() start." + " Batch Size = " + BATCH_SIZE);
            prestmt = connection.prepareStatement("values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            tmp_time = System.currentTimeMillis();
            for (RawData rawData : rawData_list) {
                Serializable[] fields = rawData.getAllFields();
                for (int i = 0; i < fields.length; i++) {
                    PostgresqlUtil.replace_placeholder(prestmt, i + 1, fields[i]);
                }
                prestmt.addBatch();
                cnt++;
                if (cnt % BATCH_SIZE == 0) {
                    connection.createStatement().addBatch(";");
                    prestmt.executeBatch();
                    prestmt.clearBatch();
                    connection.createStatement().addBatch("insert into raw_data ");
                } else {
                    connection.createStatement().addBatch(",");
                }
                if (verbose && cnt % OUTPUT_COUNT == 0) {
                    long t = System.currentTimeMillis();
                    System.out.printf("Have Loaded 50000 data in %.3f s!\n", (t - tmp_time) / 1000f);
                    tmp_time = t;
                }
            }
            if (cnt % BATCH_SIZE != 0) {
                connection.createStatement().addBatch(";");
                prestmt.executeBatch();
            }
            connection.commit();
            if (verbose)
                System.out.println("Commit!");
            end_time = System.currentTimeMillis();
            if (verbose) {
                System.out.println("Insert RawData Objects into table raw_data from data.csv successfully. " + cnt + " records are loaded");
                System.out.println("Loading Time : " + (end_time - start_time) / 1000f + " s");
                System.out.println("Loading speed : " + (cnt * 1000L) / (end_time - start_time) + " records/s");
            } else {
                System.out.println("RawDataDaoImpl insert_B()," + " Batch Size = " + BATCH_SIZE + ", Time : " + (end_time - start_time) / 1000f + " s");
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
            try {
                connection.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            System.exit(3);
        } finally {
            PostgresqlUtil.closeResource(connection, prestmt);
            System.out.println();
        }
    }

    @Override
    public void dropAll(boolean verbose) {
        Statement stmt = null;
        long start_time;
        long end_time;
        try {
            connection = PostgresqlUtil.getConnection(verbose);
            System.out.println("RawDataDaoImpl dropAll() start");
            start_time = System.currentTimeMillis();
            stmt = connection.createStatement();
            stmt.execute("truncate table raw_data cascade");
            connection.commit();
            end_time = System.currentTimeMillis();
            System.out.println("delete all rows from table raw_data successfully.");
            System.out.println("Loading Time : " + (end_time - start_time) / 1000f + " s");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        } finally {
            PostgresqlUtil.closeResource(connection, stmt);
            System.out.println();
        }
    }

    @Override
    public void importData(boolean verbose) {
        System.err.println("Using importData() in RawDataDaoImpl!");
    }

    @Override
    public void loadAndImport_from_csv(String recordsCSV, String staffsCSV) {
        Statement stmt = null;
        int cnt1 = 0;
        int cnt2 = 0;
        String[] dataFile1, dataFile2;
        String line1, line2;
        String[] parts1, parts2;
        PreparedStatement prestmt1 = null;
        PreparedStatement prestmt2 = null;

        try  {
            connection = PostgresqlUtil.getConnectionRoot();
            if (verbose)
                System.out.println("RawDataDaoImpl loadAndImport_from_csv() start");

            stmt = connection.createStatement();
            stmt.execute("truncate table raw_data_records cascade");
            stmt.execute("truncate table raw_data_staffs cascade");

            prestmt1 = connection.prepareStatement("insert into raw_data_records"
                    + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            prestmt2 = connection.prepareStatement("insert into raw_data_staffs"
                    + " values(?,?,?,?,?,?,?,?)");

            // 导入 raw_data_records
            dataFile1 = recordsCSV.split("\n");
            for(int cur = 1; /* jump header */  cur < dataFile1.length; ++cur) {
                line1 = dataFile1[cur];
                parts1 = line1.split(",");
                if (parts1.length > 1) {
                    for (int i = 0; i <= 1; i++)
                        PostgresqlUtil.replace_placeholder(prestmt1, i + 1, parts1[i], Types.VARCHAR);
                    PostgresqlUtil.replace_placeholder(prestmt1, 3, parts1[2], Types.INTEGER);
                    for (int i = 3; i <= 8; i++)
                        PostgresqlUtil.replace_placeholder(prestmt1, i + 1, parts1[i], Types.VARCHAR);
                    for (int i = 9; i <= 10; i++)
                        PostgresqlUtil.replace_placeholder(prestmt1, i + 1, parts1[i], Types.NUMERIC);
                    for (int i = 11; i <= 17; i++)
                        PostgresqlUtil.replace_placeholder(prestmt1, i + 1, parts1[i], Types.VARCHAR);

                    prestmt1.addBatch();
                    cnt1++;
                    if (cnt1 % BATCH_SIZE == 0) {
                        prestmt1.executeBatch();
                        prestmt1.clearBatch();
                    }
                }
            }
            if (cnt1 % BATCH_SIZE != 0) {
                prestmt1.executeBatch();
            }
            connection.commit();
            if (verbose)
                System.out.println("Commit!");
            if (verbose) {
                System.out.println("DROP all tuples and LOAD data into table raw_data_records SUCCESSFULLY. " + cnt1 + " records are loaded");
            } else {
                System.out.println("RawDataDaoImpl loadAndImport_from_csv(), imported to raw_data_records");
            }

            // 导入 raw_data_staffs
            dataFile2 = staffsCSV.split("\n");
            for(int cur = 1; /* jump header */  cur < dataFile2.length; ++cur) {
                line2 = dataFile2[cur];
                parts2 = line2.split(",");
                if (parts2.length > 1) {
                    for (int i = 0; i <= 4; i++)
                        PostgresqlUtil.replace_placeholder(prestmt2, i + 1, parts2[i], Types.VARCHAR);
                    PostgresqlUtil.replace_placeholder(prestmt2, 6, parts2[5], Types.INTEGER);
                    for (int i = 6; i <= 7; i++)
                        PostgresqlUtil.replace_placeholder(prestmt2, i + 1, parts2[i], Types.VARCHAR);
                    prestmt2.addBatch();
                    cnt2++;
                    if (cnt2 % BATCH_SIZE == 0) {
                        prestmt2.executeBatch();
                        prestmt2.clearBatch();
                    }
                }
            }
            if (cnt2 % BATCH_SIZE != 0) {
                prestmt2.executeBatch();
            }
            connection.commit();
            if (verbose)
                System.out.println("Commit!");
            if (verbose) {
                System.out.println("DROP all tuples and LOAD data into table raw_data_staffs SUCCESSFULLY. " + cnt2 + " records are loaded");
            } else {
                System.out.println("RawDataDaoImpl loadAndImport_from_csv(), imported to raw_data_staffs");
            }

        } catch (SQLException e1) {
            e1.printStackTrace();
            try {
                connection.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            System.exit(3);
        }
        /*
        catch (IOException e1) {
            System.err.println("Fatal error: " + e1.getMessage());
            e1.printStackTrace();
            try {
                connection.rollback();
            } catch (Exception e2) {
                System.err.println("SQL error: " + e2.getMessage());
                e2.printStackTrace();
                System.exit(3);
            }
            System.exit(2);
        }
        */
        finally {
            PostgresqlUtil.closeResource(connection, stmt, prestmt1, prestmt2);
            System.out.println();
        }
    }
}
