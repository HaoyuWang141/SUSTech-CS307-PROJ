package main.model.dao.impl;

import main.entity.Entity;
import main.entity.Log;
import main.enumcase.ExitStatus;
import main.model.dao.LogDao;
import main.util.PostgresqlUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import static main.util.PostgresqlUtil.execute_query;
import static main.util.PostgresqlUtil.verbose;

public class LogDaoImpl implements LogDao {
    Connection connection = null;

    @Override
    public Entity[] loadData(boolean verbose) {
        return new Entity[0];
    }

    @Override
    public void importData(boolean verbose) {
        Statement stmt = null;
        try {
            // connection
            connection = PostgresqlUtil.getConnectionRoot();
            System.out.println("LogDaoImpl importData() start");

            // Drop table
            stmt = connection.createStatement();
            stmt.execute("truncate table log cascade;");

            // import from raw_data
            String sql = """
                    insert into log(staff_id, password)
                    select staff.id, raw_data_staffs."Password"
                    from staff join raw_data_staffs
                         on staff.name = raw_data_staffs."Name" and staff.type = raw_data_staffs."Type";
                    """;
            stmt.execute(sql);
            connection.commit();

            System.out.println("Load Data into table log SUCCESSFULLY.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.SQLException.getCode());
        } finally {
            PostgresqlUtil.closeResource(connection, stmt);
            System.out.println();
        }
    }

    @Override
    public void insert(boolean verbose, Entity[] entities) {

    }

    @Override
    public void dropAll(boolean verbose) {

    }

    @Override
    public Log[] getLog(String loader_cnf, int staff_id) {
        String sql;
        ArrayList<Log> logs = new ArrayList<>();
        try {
            connection = PostgresqlUtil.getConnection(loader_cnf);
            sql = "select * from log where staff_id = ?";
            ResultSet resultSet = execute_query(connection, sql, new Integer[]{staff_id});
            if (verbose)
                System.out.println("get logs from table log by staff id successfully");
            while (resultSet.next()) {
                logs.add(new Log(resultSet.getInt(1),
                        resultSet.getString(2)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            PostgresqlUtil.closeResource(connection);
        }
        return logs.toArray(new Log[0]);
    }
}
