package main.model.dao.impl;

import main.entity.Container;
import main.entity.Entity;
import main.enumcase.ExitStatus;
import main.model.dao.ContainerDao;

import main.util.PostgresqlUtil;

import java.sql.*;
import java.util.ArrayList;

import static main.util.PostgresqlUtil.execute_query;
import static main.util.PostgresqlUtil.verbose;

public class ContainerDaoImpl implements ContainerDao {
    private Connection connection = null;

    @Override
    public Entity[] loadData(boolean verbose) {
        ArrayList<Container> containers = new ArrayList<>();
        long start_time;
        long end_time;
        try {
            connection = PostgresqlUtil.getConnectionRoot();
            if (verbose)
                System.out.println("ContainerDaoImpl loadData() start");
            start_time = System.currentTimeMillis();
            String sql = "select * from container";
            ResultSet resultSet = execute_query(connection, sql, null);
            end_time = System.currentTimeMillis();
            System.out.println("Load Data into java from table container successfully in " + (end_time - start_time) / 1000f + " s");
            while (resultSet.next()) {
                Container container = new Container();
                container.setCode(resultSet.getString("code"));
                container.setType(resultSet.getString("type"));
                containers.add(container);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.SQLException.getCode());
        } finally {
            PostgresqlUtil.closeResource(connection);
            System.out.println();
        }
        return containers.toArray(new Container[0]);
    }

    @Override
    public void importData(boolean verbose) {
        Statement stmt = null;
        try {
            // connection
            connection = PostgresqlUtil.getConnectionRoot();
            System.out.println("ContainerDaoImpl importData() start");

            // Drop table
            stmt = connection.createStatement();
            stmt.execute("truncate table container cascade;");

            // import from raw_data
            String sql;
            sql = """
                    insert into container(code, type, "using")
                    select distinct "Container Code", "Container Type", true
                    from raw_data_records
                    where "Container Code" is not null and
                          "Item State" in ('Packing to Container', 'Waiting for Shipping', 'Shipping');
                    """;
            stmt.execute(sql);
            sql = """
                    insert into container(code, type, "using")
                    select "Container Code", "Container Type", false
                    from raw_data_records
                    where "Container Code" is not null
                    on conflict (code) do nothing;
                    """;
            stmt.execute(sql);
            connection.commit();

            System.out.println("Load Data into table container SUCCESSFULLY.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.SQLException.getCode());
        } finally {
            PostgresqlUtil.closeResource(connection, stmt);
            System.out.println();
        }
    }

    @Override
    public void insert(boolean verbose, Entity[] entities) {

    }

    @Override
    public void dropAll(boolean verbose) {

    }

    @Override
    public Container[] getContainer(String loader_cnf, String container_code) {
        String sql;
        ArrayList<Container> containers = new ArrayList<>();
        try {
            connection = PostgresqlUtil.getConnection(loader_cnf);
            sql = "select * from container where code like ?";
            ResultSet resultSet = execute_query(connection, sql, new String[]{container_code});
            if (verbose)
                System.out.println("get city count from table city successfully");
            while (resultSet.next()) {
                containers.add(new Container(resultSet.getString(1),
                        resultSet.getString(2),
                        resultSet.getBoolean(3)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            PostgresqlUtil.closeResource(connection);
        }
        return containers.toArray(new Container[0]);
    }
}
