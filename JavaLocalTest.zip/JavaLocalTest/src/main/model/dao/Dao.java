package main.model.dao;

import main.model.AccessObject;

public interface Dao extends AccessObject {
}
