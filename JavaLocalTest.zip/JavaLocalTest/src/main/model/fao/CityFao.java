package main.model.fao;

public interface CityFao extends Fao {
}
