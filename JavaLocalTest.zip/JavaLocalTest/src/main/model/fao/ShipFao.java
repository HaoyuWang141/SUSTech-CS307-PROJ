package main.model.fao;


public interface ShipFao extends Fao {
}
