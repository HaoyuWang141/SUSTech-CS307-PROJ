package main.model.fao;



public interface CourierFao extends Fao {
}
