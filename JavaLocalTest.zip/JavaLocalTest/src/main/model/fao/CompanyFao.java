package main.model.fao;

public interface CompanyFao extends Fao {
}
