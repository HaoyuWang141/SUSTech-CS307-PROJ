package main.model.fao;


public interface ContainerFao extends Fao {
}
