package main.model.fao;

import main.model.AccessObject;

public interface Fao extends AccessObject {
}
