package main.model.fao;

public interface CityTaxFao extends Fao {
}
