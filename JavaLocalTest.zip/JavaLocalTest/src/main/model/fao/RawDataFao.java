package main.model.fao;

public interface RawDataFao extends Fao {

}