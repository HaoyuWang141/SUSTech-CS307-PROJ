package main.enumcase;

public enum SOURCE {
    database, csv, json
}
