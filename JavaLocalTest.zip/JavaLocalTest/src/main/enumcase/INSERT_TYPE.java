package main.enumcase;

public enum INSERT_TYPE {
    DAO_FAO_A,DAO_FAO_B,DAO_CSV
}
