package main.servlet;

import main.enumcase.SOURCE;
import main.service.*;
import main.service.impl.*;

public class Client_Import_Data_csv {
    private static String fileName = null;
    private static boolean verbose = true;
//    public static INSERT_TYPE type;

    public static void main(String[] args) {

        /*
        1. create table data (in datagrip)
        2. import data from csv
        3. create table xxx (DDL) (in datagrip)
        4. insert data from table "data" (DML)
        ///finish database///
        5. other operations (insert / delete / update / select)
        */

//        switch (args.length) {
//            case 1:
//                fileName = args[0];
//                break;
//            case 2:
//                switch (args[0]) {
//                    case "-v":
//                        verbose = true;
//                        break;
//                    default:
//                        System.err.println("Usage: java [-v] GoodLoader filename");
//                        System.exit(1);
//                }
//                fileName = args[1];
//                break;
//            default:
//                System.err.println("Usage: java [-v] GoodLoader filename");
//                System.exit(1);
//        }

        long start_time = System.currentTimeMillis();

        RawDataService rawDataService = new RawDataServiceImpl();
        CityService cityService = new CityServiceImpl();
        CityTaxService cityTaxService = new CityTaxServiceImpl();
        CompanyService companyService = new CompanyServiceImpl();
        ContainerService containerService = new ContainerServiceImpl();
        StaffService staffService = new StaffServiceImpl();
        ShipService shipService = new ShipServiceImpl();
        DeliveryService deliveryService = new DeliveryServiceImpl();

        rawDataService.importData(verbose, SOURCE.csv, null);
        cityService.importData(verbose, SOURCE.csv);
        cityTaxService.importData(verbose, SOURCE.csv);
        companyService.importData(verbose, SOURCE.csv);
        containerService.importData(verbose, SOURCE.csv);
        staffService.importData(verbose, SOURCE.csv);
        shipService.importData(verbose, SOURCE.csv);
        deliveryService.importData(verbose, SOURCE.csv);

        long end_time = System.currentTimeMillis();
        System.out.println("Total Time: " + (end_time - start_time) / 1000f + " s");
    }
}