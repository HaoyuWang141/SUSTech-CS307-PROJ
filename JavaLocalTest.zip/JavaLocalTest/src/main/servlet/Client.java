package main.servlet;

public class Client {
    private static String fileName = null;
    private static boolean verbose = false;

    public static void main(String[] args) {

        /*
        1. create table data (in datagrip)
        2. import data from csv
        3. create table xxx (DDL) (in datagrip)
        4. insert data from table "data" (DML)
        ///finish database///

        5. other operations (insert / delete /update
        */

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] GoodLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] GoodLoader filename");
                System.exit(1);
        }
    }
}

