package main.servlet;

import main.enumcase.SOURCE;
import main.service.DeliveryService;
import main.service.impl.DeliveryServiceImpl;

public class Client_DELETE {
    private static String fileName = null;
    private static boolean verbose = true;

    public static void main(String[] args) {
//        switch (args.length) {
//            case 1:
//                fileName = args[0];
//                break;
//            case 2:
//                switch (args[0]) {
//                    case "-v":
//                        verbose = true;
//                        break;
//                    default:
//                        System.err.println("Usage: java [-v] GoodLoader filename");
//                        System.exit(1);
//                }
//                fileName = args[1];
//                break;
//            default:
//                System.err.println("Usage: java [-v] GoodLoader filename");
//                System.exit(1);
//        }
        DeliveryService deliveryService = new DeliveryServiceImpl();
        long database_start_time = System.currentTimeMillis();
        deliveryService._2_deleteApple(verbose, SOURCE.database);
        long database_end_time = System.currentTimeMillis();
        long csv_start_time = System.currentTimeMillis();
        deliveryService._2_deleteApple(verbose, SOURCE.csv);
        long csv_end_time = System.currentTimeMillis();
        System.out.println("_2_deleteApple time cost:");
        System.out.println("database: " + (database_end_time - database_start_time) / 1000f + " s");
        System.out.println("csv : " + (csv_end_time - csv_start_time) / 1000f + " s");
    }
}
