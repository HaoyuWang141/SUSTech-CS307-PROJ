package main.servlet;

import main.enumcase.SOURCE;
import main.service.DeliveryService;
import main.service.impl.DeliveryServiceImpl;

public class Client_SELECT {
    private static String fileName = null;
    private static boolean verbose = false;
    public static void main(String[] args) {
//        switch (args.length) {
//            case 1:
//                fileName = args[0];
//                break;
//            case 2:
//                switch (args[0]) {
//                    case "-v":
//                        verbose = true;
//                        break;
//                    default:
//                        System.err.println("Usage: java [-v] GoodLoader filename");
//                        System.exit(1);
//                }
//                fileName = args[1];
//                break;
//            default:
//                System.err.println("Usage: java [-v] GoodLoader filename");
//                System.exit(1);
//        }
        DeliveryService deliveryService = new DeliveryServiceImpl();
        long database_start_time = System.currentTimeMillis();
        deliveryService._4_selectUnfinished(verbose, SOURCE.database);
        long database_end_time = System.currentTimeMillis();
        long csv_start_time = System.currentTimeMillis();
        deliveryService._4_selectUnfinished(verbose, SOURCE.csv);
        long csv_end_time = System.currentTimeMillis();
        System.out.println("_4_selectUnfinished time cost:");
        System.out.println("database: " + (database_end_time - database_start_time) / 1000f + " s");
        System.out.println("csv : " + (csv_end_time - csv_start_time) / 1000f + " s");

        database_start_time = System.currentTimeMillis();
        deliveryService._5_selectOnContainer(verbose, SOURCE.database,"");
        database_end_time = System.currentTimeMillis();
        csv_start_time = System.currentTimeMillis();
        deliveryService._5_selectOnContainer(verbose,SOURCE.csv,"");
        csv_end_time = System.currentTimeMillis();
        System.out.println("_5_selectOnContainer time cost:");
        System.out.println("database: " + (database_end_time - database_start_time) / 1000f + " s");
        System.out.println("csv : " + (csv_end_time - csv_start_time) / 1000f + " s");
    }
}
