package main.servlet;

import main.enumcase.INSERT_TYPE;
import main.enumcase.SOURCE;
import main.service.*;
import main.service.impl.*;

public class Client_Import_Data_database {
    private static String fileName = null;
    private static boolean verbose = false;
//    public static INSERT_TYPE type;

    public static void main(String[] args) {

        /*
        1. create table data (in datagrip)
        2. import data from csv
        3. create table xxx (DDL) (in datagrip)
        4. insert data from table "data" (DML)
        ///finish database///
        5. other operations (insert / delete / update / select)
        */

//        switch (args.length) {
//            case 1:
//                fileName = args[0];
//                break;
//            case 2:
//                switch (args[0]) {
//                    case "-v":
//                        verbose = true;
//                        break;
//                    default:
//                        System.err.println("Usage: java [-v] GoodLoader filename");
//                        System.exit(1);
//                }
//                fileName = args[1];
//                break;
//            default:
//                System.err.println("Usage: java [-v] GoodLoader filename");
//                System.exit(1);
//        }

        long start_time = System.currentTimeMillis();

        RawDataService rawDataService = new RawDataServiceImpl();
        CityService cityService = new CityServiceImpl();
        CityTaxService cityTaxService = new CityTaxServiceImpl();
        CompanyService companyService = new CompanyServiceImpl();
        ContainerService containerService = new ContainerServiceImpl();
        StaffService staffService = new StaffServiceImpl();
        ShipService shipService = new ShipServiceImpl();
        DeliveryService deliveryService = new DeliveryServiceImpl();

//        rawDataService.importData(verbose, SOURCE.database, INSERT_TYPE.DAO_FAO_A);
//        rawDataService.importData(verbose, SOURCE.database, INSERT_TYPE.DAO_FAO_B);
        rawDataService.importData(verbose, SOURCE.database, INSERT_TYPE.DAO_CSV);

        cityService.importData(verbose, SOURCE.database);
        cityTaxService.importData(verbose, SOURCE.database);
        companyService.importData(verbose, SOURCE.database);
        containerService.importData(verbose, SOURCE.database);
        staffService.importData(verbose, SOURCE.database);
        shipService.importData(verbose, SOURCE.database);
        deliveryService.importData(verbose, SOURCE.database);

        long end_time = System.currentTimeMillis();
        System.out.println("Total Time: " + (end_time - start_time) / 1000f + " s");
    }
}