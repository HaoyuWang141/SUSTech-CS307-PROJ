package main.for_test;

// 用来随便写点东西，并无任何用处
public class main {
    public static void main(String[] args) {
//        for (int i = 0; i < 25; i++) {
//            System.out.print("?,");
//        }

//        System.out.print("?");
//        Date date = Date.valueOf();
//        System.out.println(date);

//        Double d = 2.;
//        Double c = Double.parseDouble("2.");
//        Integer a = d.intValue();
//        Integer b = c.intValue();
//        System.out.println(d+" "+c+" "+a+" "+b);

//        Entity a = new CityTax();
//        City b = new City();
//        City c = (City) a;
//        System.out.println(a);
//        System.out.println(b);
//        System.out.println(c);
    }
}
