package main.Validation;

import main.entity.Entity;
import main.enumcase.SOURCE;
import main.service.*;
import main.service.impl.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


public class Data_Import_Validation {
    private static boolean verbose = true;

    public static void main(String[] args) {
        CityService cityService = new CityServiceImpl();
        CityTaxService cityTaxService = new CityTaxServiceImpl();
        CompanyService companyService = new CompanyServiceImpl();
        ContainerService containerService = new ContainerServiceImpl();
        StaffService staffService = new StaffServiceImpl();
        ShipService shipService = new ShipServiceImpl();
        DeliveryService deliveryService = new DeliveryServiceImpl();
//        tables_are_equal(verbose, cityService, "city");
//        tables_are_equal(verbose, cityTaxService, "city_tax");
//        tables_are_equal(verbose, companyService, "company");
//        tables_are_equal(verbose, containerService, "container");
//        tables_are_equal(verbose, shipService, "ship");
//        tables_are_equal(verbose, courierService, "courier");
        tables_are_equal(verbose, deliveryService, "delivery");
    }

    private static boolean tables_are_equal(boolean verbose, Service service, String table_name) {
        boolean equal = true;
        ArrayList<Entity> result_db = new ArrayList<>(Arrays.asList(service.loadData(verbose, SOURCE.database)));
        ArrayList<Entity> result_csv = new ArrayList<>(Arrays.asList(service.loadData(verbose, SOURCE.csv)));
        Set<Entity> set = new HashSet<>(result_db);
        if (!set.containsAll(result_csv)) equal = false;
        set.clear();
        set.addAll(result_csv);
        if (!set.containsAll(result_db)) equal = false;
        if (verbose) {
            System.out.println("entities from db_table " + table_name);
            int cnt = 0;
            for (Entity entity : result_db) {
                System.out.println(entity.toString());
                if (cnt == 1000) break;
                cnt++;
            }
            cnt = 0;
            System.out.println("entities from " + table_name + ".csv");
            for (Entity entity : result_csv) {
                System.out.println(entity.toString());
                if (cnt == 1000) break;
                cnt++;
            }
        }
        System.out.println("db_table " + table_name + " = " + table_name + ".csv : " + equal);
        System.out.println();
        return equal;
    }
}
