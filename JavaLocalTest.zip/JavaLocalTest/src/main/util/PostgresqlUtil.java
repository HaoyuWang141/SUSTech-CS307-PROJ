package main.util;

import main.enumcase.ExitStatus;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;

public class PostgresqlUtil {
    public static Connection CON = null;
    public static final double ERROR = 1E-4;
    public static String database;
    public static String root;
    public static String pass;
    private static final String driver = "org.postgresql.Driver";
    private static URL propertyURL = PostgresqlUtil.class.getResource("/main/util/loader_why.cnf");
    public static boolean verbose = false;
    public static final int BATCH_SIZE = 500;

    public static String DATA_CSV_PATH = "./data/data.csv";
    public static String RAW_DATA_CSV_PATH = "./data/csv/raw_data.csv";
    public static String ALTERED_DATA_CSV_PATH = "./data/csv/altered_raw_data.csv";
    public static String CITY_CSV_PATH = "./data/csv/city.csv";
    public static String CITY_TAX_CSV_PATH = "./data/csv/city_tax.csv";
    public static String COMPANY_CSV_PATH = "./data/csv/company.csv";
    public static String CONTAINER_CSV_PATH = "./data/csv/container.csv";
    public static String COURIER_CSV_PATH = "./data/csv/courier.csv";
    public static String DELIVERY_CSV_PATH = "./data/csv/delivery.csv";
    public static String SHIP_CSV_PATH = "./data/csv/ship.csv";

    public static int MAX_IMPORT_AMOUNT = 600000;
    private static Properties props = new Properties();

    public static Connection getConnectionRoot() {
        Connection connection = null;
        try {
            Class.forName(driver);
        } catch (Exception e) {
            System.err.println("Cannot find the Postgres driver. Check CLASSPATH.");
            System.exit(ExitStatus.ParameterException.getCode());
        }
        String url = "jdbc:postgresql://" + database;
        Properties props = new Properties();
        props.setProperty("user", root);
        props.setProperty("password", pass);
        try {
            connection = DriverManager.getConnection(url, props);
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.IOException.getCode());
        }
        return connection;
    }

    public static Connection getConnection(String host, String dbname, String user, String pwd) {
        Connection connection = null;
        try {
            Class.forName(driver);
        } catch (Exception e) {
            System.err.println("Cannot find the Postgres driver. Check CLASSPATH.");
            System.exit(ExitStatus.ParameterException.getCode());
        }
        String url = "jdbc:postgresql://" + host + "/" + dbname;
        Properties props = new Properties();
        props.setProperty("user", user);
        props.setProperty("password", pwd);
        try {
            connection = DriverManager.getConnection(url, props);
            if (verbose) {
                System.out.println("Successfully connected to the database " + dbname + " as " + user);
            }
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.IOException.getCode());
        }
        return connection;
    }

    public static Connection getConnection(String database, String user, String pwd) {
        Connection connection = null;
        try {
            Class.forName(driver);
        } catch (Exception e) {
            System.err.println("Cannot find the Postgres driver. Check CLASSPATH.");
            System.exit(ExitStatus.ParameterException.getCode());
        }
        props.setProperty("user", user);
        props.setProperty("password", pwd);
        try {
            connection = DriverManager.getConnection("jdbc:postgresql://" + database, props);
            if (verbose) {
                System.out.println("Successfully connected to the database " + database + " as " + user);
            }
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(ExitStatus.IOException.getCode());
        }
        return connection;
    }

    public static Connection getConnection(String load_cnf) {
        Connection connection = null;
        try {
            Class.forName(driver);
        } catch (Exception e) {
            System.err.println("Cannot find the Postgres driver. Check CLASSPATH.");
            System.exit(ExitStatus.SQLException.getCode());
        }

        propertyURL = PostgresqlUtil.class.getResource("/main/util/" + load_cnf);
        if (propertyURL == null) {
            System.err.println("No configuration file (" + load_cnf + ") found");
            System.exit(1);
        }

        try (BufferedReader conf = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            props.load(conf);
        } catch (IOException e) {
            System.err.println("No configuration file (" + load_cnf + ") found");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }

        String url = "jdbc:postgresql://" + props.getProperty("host") + "/" + props.getProperty("database") + props.getProperty("stringtype");
        Properties props_login = new Properties();
        props_login.setProperty("user", props.getProperty("user"));
        props_login.setProperty("password", props.getProperty("password"));
        try {
            connection = DriverManager.getConnection(url, props_login);
            if (verbose) {
                System.out.println("Successfully connected to the database " + props.getProperty("database") + " as " + props.getProperty("user"));
            }
            connection.setAutoCommit(true);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(3);
        }
        return connection;
    }

    public static Connection getConnection(boolean verbose) {
        Connection connection = null;
        try {
            Class.forName(driver);
        } catch (Exception e) {
            System.err.println("Cannot find the Postgres driver. Check CLASSPATH.");
            System.exit(ExitStatus.SQLException.getCode());
        }

        if (propertyURL == null) {
            System.err.println("No configuration file (loader_why.cnf) found");
            System.exit(1);
        }

        try (BufferedReader conf = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            props.load(conf);
        } catch (IOException e) {
            System.err.println("No configuration file (loader_why.cnf) found");
        }

        String url = "jdbc:postgresql://" + props.getProperty("host") + "/" + props.getProperty("database") + props.getProperty("stringtype");
        Properties props_login = new Properties();
        props_login.setProperty("user", props.getProperty("user"));
        props_login.setProperty("password", props.getProperty("password"));
        try {
            connection = DriverManager.getConnection(url, props_login);
            if (verbose) {
                System.out.println("Successfully connected to the database " + props.getProperty("database") + " as " + props.getProperty("user"));
            }
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(3);
        }
        return connection;
    }

    public static void closeResource(AutoCloseable... autoCloseable) {
        for (AutoCloseable resource : autoCloseable) {
            if (resource != null) {
                try {
                    resource.close();
                } catch (SQLException e) {
                    System.err.println("Close Database(Postgresql) Resource Failed: \n");
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * close resource and close database
     */

    // Query
    public static ResultSet execute_query(Connection connection, String sql, Object[] params) throws SQLException {
        ResultSet resultSet = null;
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            if (params != null)
                for (int i = 0; i < params.length; i++) {
                    preparedStatement.setObject(i + 1, params[i]);
                }
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return resultSet;
    }

    // Insert, Update, Delete, DDL
    public static int execute_update(Connection connection, String sql, Object[] params) throws SQLException {
        int updateRows = 0;
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            if (params != null)
                for (int i = 0; i < params.length; i++) {
                    preparedStatement.setObject(i + 1, params[i]);
                }
            updateRows = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return updateRows;
    }

    // 该方法用来将占位符替换为指定类型的数据，如果str=""，则替换为指定类型(sqlType)的null
    // "replace_placeholder" is
    public static void replace_placeholder(PreparedStatement prestmt, int parameterIndex, String str, int sqlType) {
        try {
            if (str.equals("")) prestmt.setNull(parameterIndex, sqlType);
            else
                switch (sqlType) {
                    case Types.VARCHAR:
                    case Types.CHAR:
                        prestmt.setString(parameterIndex, str);
                        break;
                    case Types.INTEGER:
                        prestmt.setInt(parameterIndex, (int) (Double.parseDouble(str)));
                        break;
                    case Types.NUMERIC:
                        prestmt.setDouble(parameterIndex, Double.parseDouble(str));
                        break;
                    case Types.DATE:
                        prestmt.setDate(parameterIndex, Date.valueOf(str));
                        break;
                    case Types.TIMESTAMP:
                        prestmt.setTimestamp(parameterIndex, Timestamp.valueOf(str));
                        break;
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void replace_placeholder(PreparedStatement prestmt, int parameterIndex, Serializable field) {
        try {
            int sqlType = getSqlType(field);
            if (field == null) prestmt.setNull(parameterIndex, sqlType);
            else
                switch (sqlType) {
                    case Types.VARCHAR:
                    case Types.CHAR:
                        prestmt.setString(parameterIndex, (String) field);
                        break;
                    case Types.INTEGER:
                        prestmt.setInt(parameterIndex, (Integer) field);
                        break;
                    case Types.NUMERIC:
                        prestmt.setDouble(parameterIndex, (Double) field);
                        break;
                    case Types.DATE:
                        prestmt.setDate(parameterIndex, (Date) field);
                        break;
                    case Types.TIMESTAMP:
                        prestmt.setTimestamp(parameterIndex, (Timestamp) field);
                        break;
                }
        } catch (NullPointerException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Integer> get_types(String table_name, boolean verbose) {
        ArrayList<Integer> type_arr = new ArrayList<>();
        Connection con = getConnection(verbose);
        String pre_sql = "SELECT column_name, data_type, ordinal_position, is_nullable\n" +
                         "FROM information_schema.\"columns\"\n" +
                         "WHERE \"table_name\"=?\n" +
                         "ORDER BY ordinal_position;";
        ResultSet resultSet;
        try {
            PreparedStatement prestmt = con.prepareStatement(pre_sql);
            prestmt.setString(1, table_name);
            resultSet = prestmt.executeQuery();
            while (resultSet.next()) {
                type_arr.add(resultSet.getInt("data_type"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return type_arr;
    }

    public static int getSqlType(Serializable field) {
        int type = Types.NULL;
        if (field != null)
            switch (field.getClass().getName()) {
                case "java.lang.String":
                    type = Types.VARCHAR;
                    break;
                case "java.lang.Integer":
                    type = Types.INTEGER;
                    break;
                case "java.lang.Double":
                    type = Types.NUMERIC;
                    break;
                case "java.sql.Date":
                    type = Types.DATE;
                    break;
                case "java.sql.Timestamp":
                    type = Types.TIMESTAMP;
                    break;
            }
        return type;
    }
}
